.packageName <- "CORNA"
`BioMart2df.fun` <-
function(biomart="ENSEMBL_MART_ENSEMBL", 
                           dataset="mmusculus_gene_ensembl", 
                           host="www.ensembl.org",
                           col.old=NULL,
                           col.new=col.old,
                           complete=FALSE){
  mart.obj <- useMart(biomart=biomart, dataset=dataset, host=host)
  # listAttributes(mart.obj)
  d <- getBM(col.old, mart=mart.obj, uniqueRows=TRUE)
  if(ncol(d)>1 && complete==FALSE){
    for(r in col.old){
      d <- d[d[, r]!="", ]
    }
    d <- na.omit(d)
    rownames(d) <- c(1:nrow(d))
    colnames(d) <- col.new
  } 
  return(d)
}

`GEO2df.fun` <-
function(file=NULL, url=NULL, string=NULL){
  if(!is.null(file) || !is.null(url)){                        
    file <- getfile.fun(file=file, url=url)
    geo <- getGEO(filename=file)            # read GEO object from file
  }
  else{                                     # when file and url are both undefined
    if(!is.null(string)){                   # read GEO object from string
      geo <- getGEO(GEO=string)
    }
    else{                                   # report error if string is also undefined
      stop("Please supply a filename of a GEO file, or the url of downloading it or a GEO accession")
    }
  }
  
  # make microarray data frame from GEO object
  probes <- Table(GPLList(geo)[[1]])$ID
  mat    <- do.call("cbind", lapply(GSMList(geo),
                    function(x){
                      tab <- Table(x)
                      mymatch <- match(probes, tab$ID_REF)
                      return(tab$VALUE[mymatch])
                    }))
  mat[is.na(mat)] <- 0                    # set NA's as 0s
  mat[mat <= 0]   <- 0.5                  # set negatives and 0s to small value
  genes           <- Table(geo@gpls[[1]]) # get the genes

  # define data type, row names and column names of the microarry matrix
  data.frame(matrix(as.numeric(mat), nrow=nrow(mat), ncol=ncol(mat),
                    dimnames=list(genes$ID, colnames(mat))))
}

`GO2df.fun` <-
function(file=NULL, url=NULL, col.new=c("goid", "term")){
  file <- getfile.fun(file=file, url=url)  
  d <- read.table(file, skip=1, header=F, sep="\t", quote="", comment.char="")
  d <- unique(d[c("V3", "V6")])
  colnames(d) <- col.new
  rownames(d) <- c(1:nrow(d))
  return(d)
}

`KEGG2df.fun` <-
function(kegg2gene.file=NULL, kegg2gene.url=NULL, 
         kegg2path.file=NULL, kegg2path.url=NULL, 
         path2name.file=NULL, path2name.url=NULL, 
         org=NULL, col.new=c("gene", "path", "name")){
  if(!is.null(org)){
    url <- paste("ftp://ftp.genome.jp/pub/kegg/genes/organisms/", org, "/", org, "_", sep="")
    if(is.null(kegg2gene.file) && is.null(kegg2gene.url)){
      kegg2gene.url <- paste(url, "ensembl-", org, ".list", sep="")
    }
    if(is.null(kegg2path.file) && is.null(kegg2path.url)){
      kegg2path.url <- paste(url, "pathway.list", sep="")
    }
  }
  if(is.null(path2name.file) && is.null(path2name.url)){
    path2name.url <- "ftp://ftp.genome.jp/pub/kegg/pathway/map_title.tab"
  }
  if(is.null(org)){
    if(!is.null(kegg2gene.url)){
      v <- strsplit(kegg2gene.url, "/")[[1]]
    }
    else{
      v <- strsplit(kegg2gene.file, "/")[[1]]
    }
    org <- strsplit(v[length(v)], "_")[[1]][1]
  }
  
  k2g.file   <- getfile.fun(file=kegg2gene.file, url=kegg2gene.url)
  k2g.df     <- read.table(k2g.file)
  k2g.df[,1] <- sub(paste(org, ":", sep=""), "", k2g.df[,1])
  k2g.df[,2] <- sub(paste("ensembl-", org, ":", sep=""), "", k2g.df[,2])
    
  k2p.file   <- getfile.fun(file=kegg2path.file, url=kegg2path.url)
  k2p.df     <- read.table(k2p.file)
  k2p.df[,1] <- sub(paste(org, ":", sep=""), "", k2p.df[,1])
  k2p.df[,2] <- sub(paste("path:", org, sep=""), "", k2p.df[,2])
  
  p2n.file   <- getfile.fun(file=path2name.file, url=path2name.url)
  p2n.line   <- readLines(p2n.file, n=-1)                            
  p2n.vec    <- strsplit(p2n.line, "\t")                                
  p2n.df     <- data.frame(V1=sapply(p2n.vec, '[', 1)) 
  for(i in 2:length(p2n.vec[[1]])){                           
    p2n.df[, i] <- sapply(p2n.vec, '[', i)                         
  }  
  
  colnames(k2g.df) <- c("k", "g")
  colnames(k2p.df) <- c("k", "p")
  colnames(p2n.df) <- c("p", "n")
   
  d.df  <- merge(k2p.df, k2g.df, sort=F)
  d.df  <- merge(d.df, p2n.df, sort=F)
  d.df  <- unique(d.df[c("g", "p", "n")]) 
  rownames(d.df) <- c(1:nrow(d.df)) 
  colnames(d.df) <- col.new  
  return(d.df) 
}
`corna.barplot.fun` <-
function(x, scale.data=T, row=1, column=1, 
         array.order=c(1:ncol(x)), 
         array.colour=rainbow(length(array.order)), 
         probe.colour=rep("black", nrow(x)), 
         las=1, ps=8, mar=c(1.5,3,2.5,1), 
         main="CORNA barplots", sub="", xlab="", ylab="", line=NA, outer=F){
  d <- na.omit(x[, array.order])
  n <- ncol(d)
  if(is.null(probe.colour)) {probe.colour <- rainbow(nrow(d))}   
  if(scale.data==T){d[,1:n] <- t(scale(t(d[,1:n])))}   
  
  split.screen(c(row, column), erase=TRUE)
  erase.screen()
  for(i in 1:min(nrow(d),(row*column)))
  {
    screen(i)
    par(las=las, ps=ps, mar=mar) 
    barplot(c(as.matrix(d[i,1:n])), col=array.colour)
    axis(1, at=ncol(d)/2, lab=rownames(x)[i], line=-1, col="black", tick=F, col.axis=probe.colour[i])
  }
  close.screen(all = TRUE) 
  title(main=main, sub=sub, xlab=xlab, ylab=ylab, line=line, outer=outer)
}     
`corna.hclust.fun` <-
function (x, method="average", members=NULL, ...){
  dist <- 1 - cor(t(x))
  hc   <- hclust(as.dist(dist), method=method, members=members)
  plot(hc, ...)
  return(hc)
}

`corna.line.fun` <-
function(x, scale.data=T,
         array.order=c(1:ncol(x)), probe.colour=NULL,  
         array.line=T, array.colour=rep("black", length(array.order)),
         las=1, ps=13, mar=c(7,3,3,1),
         type="l", xlab="", ylab="", asp="", main="CORNA lines", sub="",
         my.axis.1=axis(1, at=0:(n-1), lab=colnames(d), adj=0.5, cex.axis=0.8, col="black", tick=T),
         my.axis.2=axis(2, at=0:0, lab=0, adj=0, cex.axis=1, col="black", tick=T),
         my.axis.3="",
         my.axis.4=""){ 
  d <- na.omit(x[, array.order])
  n <- ncol(d)
  if(is.null(probe.colour)) {probe.colour <- rainbow(nrow(d))}                                        
  if(scale.data==T){d[, 1:n] <- t(scale(t(d[, 1:n])))} 
  par(las=las, ps=ps, mar=mar)
  plot(c(0:(n-1)),d[1,1:n],col=probe.colour[1],ylim=range(d[,1:n]),type=type,ylab=ylab,xlab=xlab,xaxt="n",asp=asp,main=main,sub=sub)
  my.axis.1
  my.axis.2
  my.axis.3
  my.axis.4
  if(array.line==T){for(i in 0:(n-1)){lines(c(i,i), range(d[,1:n]), col=array.colour[i+1], type="l")}}
  for(i in 2:nrow(d)){lines(c(0:(n-1)), d[i,1:n], col=probe.colour[i], type=type)}
}
`corna.map.fun` <-
function(x, y, m=NULL, n=m, all=FALSE){
  if(is.vector(x) && is.vector(y)){
    d <- intersect(x, y)
  }
  if(is.data.frame(x) && is.data.frame(y)){
    d <- merge(x, y, sort=F)
    if(all==FALSE){
      if(!is.null(m) && !is.null(n)){
      d <- unique(d[c(m, n)])
      }
      else{
        c <- intersect(colnames(x), colnames(y))
        d <- unique(d[, -match(c, names(d))])
      }
      rownames(d)=c(1:nrow(d))
    }
  }
  if(is.data.frame(x) && is.vector(y)){
    x <- unique(x[c(m, n)])
    colnames(x) <- c("c1", "c2")
    y <- data.frame(c1=y)
    d <- unique(merge(x, y, sort=F))
    if(all==FALSE){
      d <- as.vector(unique(d[, "c2"]))
    }
    else{
      colnames(d) <- c(m, n)
      rownames(d)=c(1:nrow(d))
    }
  }
  
  return(d)
}                       
`corna.sub.fun` <-
function(x, y){
  d <- x[rownames(x) %in% y, ]
  return(d)
}

`corna.test.fun` <-
function(x, y, z, min.pop=-1, min.sam=-1,
         hypergeometric=TRUE, hyper.lower.tail=FALSE, 
         fisher=FALSE, fisher.alternative="two.sided", 
         chi.square=FALSE,
         p.adjust.method="none", label=FALSE, sort="hypergeometric", desc=NULL){
                           
  sam <- data.frame(t=unique(x))                      # data frame of sample transcripts
  pop <- data.frame(t=unique(y))                      # data frame of population transcripts
  
  sam <- merge(sam, pop)                              # sample must be in population
  
  map <- data.frame(t=z[,1], m=z[,2])                 # data frame of tran-mir pairs
    
  s2m <- unique(merge(map, sam, sort=F))              # sample tran-mir pairs     
  p2m <- unique(merge(map, pop, sort=F))              # population tran-mir pairs
  stn <- nrow(sam)                                    # total number of tran in sample
  ptn <- length(y)                                    # total number of tran in population
  rat <- stn/ptn                                      # ratio of sample and population 
      
  mv <- as.vector(na.omit(unique(s2m[, "m"])))        # all of mir associated with tran in sample
  pv <- vector()                                      # number of tran associated with this miRNA in population
  sv <- vector()                                      # number of tran associated with this miRNA in sample
  ev <- vector()                                      # expected frequency if the sample was randomly selected
  hv <- vector()                                      # hypergeometric test p-value
  fv <- vector()                                      # fisher's exact test p-value 
  cv <- vector()                                      # chi-squared test p-value 
  
  for(m in mv){                                       # for each miRNA associated with some sample gene
    san <- length(unique(s2m$t[s2m$m==m]))            # number of tran associated with this miRNA in sample
    pan <- length(unique(p2m$t[p2m$m==m]))            # number of tran associated with this miRNA in population
    ean <- round(pan*rat )                            # calculate expectation 
    
    pv <- append(pv, pan)
    sv <- append(sv, san) 
    ev <- append(ev, ean)
    
    # build 2 x 2 contingency table according to 2 variables
    # variable 1 is data category: "associated with this mir" or "not associated"
    # varialbe 2 is result category: "being selected in sample" or "not selected"  
     
    n1 <- san                                         # associated     and selected 
    n2 <- stn-san                                     # not associated and selected
    n3 <- pan-san                                     # associated     and not selected
    n4 <- ptn-stn-pan+san                             # not associated and not selected
    mt <- matrix(c(n1, n2, n3, n4), nrow=2)           # create matrix Fisher's exact test
    
    if(hypergeometric==TRUE){                         # hypergeometric test (default)
      if(hyper.lower.tail==FALSE){
        san <- san-1  
      }
      hp <- phyper(san, pan, ptn-pan, stn, lower.tail=hyper.lower.tail) 
      hv <- append(hv, hp)                                 
    }
    if(fisher==TRUE){                                 # Fisher's exact test (optional)
      fp <- fisher.test(mt, alternative=fisher.alternative)$p.v  
      fv <- append(fv, fp)
    }
    if(chi.square==TRUE){                              # Chi-square test (optional)
      cp <- tryCatch(chisq.test(mt)$p.value, warning = function(x) NA)                    
      cv <- append(cv, cp)
    }
  }
        
  d <- data.frame(row.names=mv,                       # data frame for the test results
                  total=pv, 
                  expectation=ev, 
                  observation=sv)       
                  
  if(hypergeometric==TRUE){d[, "hypergeometric"] = hv} 
  if(fisher==TRUE){d[, "fisher"] = fv}
  if(chi.square==TRUE){d[, "chi.square"] = cv}
  
  d <- d[order(d[, sort]), ]                          # sort by p-value (default hypergeometric) 

  for(i in 4:length(d)){                              # adjust p-values
    d[, i] <- as.numeric(p.adjust(as.numeric(d[, i]), p.adjust.method))
    if(label==TRUE){                                  # label significant ones 
      d[d[, i] <= 0.05, i] <- paste(d[d[, i] <= 0.05, i], "*", sep="")     
      d[d[, i] <= 0.01, i] <- paste(d[d[, i] <= 0.01, i], "*", sep="") 
    }
  }
    
  if(is.data.frame(desc)){
    v <- vector()
    for(i in rownames(d)){
      j <- corna.map.fun(desc, i, 1, 2)
      t <- ""
      for(k in j){
        t <- paste(t, k, sep=":")
      }
      t <- sub(":", "", t)
      v <- append(v, t)
    }
    d[, "description"] <- v
  }
 
  if(min.pop!=-1){d <- d[d[, "total"]>=min.pop, ]}
  if(min.sam!=-1){d <- d[d[, "observation"]>=min.sam, ]}
 
  return(d)
}                                                             
  
`getfile.fun` <-
function(url=NULL, file=NULL){
  if(is.null(file)){                        # if file not defined
    if(!is.null(url)){                      # download it if url is defined
      v <- unlist(strsplit(url, "/"))
      file <- v[length(v)]
      download.file(url, file)
    }
    else{
      stop("Please supply a either a filename or the url of downloading it.")
    }
  }
  
  if(length(grep("\\.gz$", file, perl=T))>0){
    gunzip(file, overwrite=T, remove=F)
    file <- gsub("\\.gz$", "", file)
  }
    

  if(length(grep("\\.zip$", file, perl=T))>0){
    n <- sub("\\.zip$", "", file)
    n <- sub("^arch\\.", "", n)
    #file <- zip.file.extract(n, file)
    unzip(zipfile=file)
    file <- n
  }
  
  return(file)
}

`miRBase2df.fun` <-
function(file=NULL, url=NULL, slim=TRUE,
                           col.old=c("TRANSCRIPT_ID", "SEQ"),
                           col.new=c("tran", "mir")){
  file <- getfile.fun(file=file, url=url)
  d <- read.table(file, skip=5, sep="\t", stringsAsFactor=FALSE)
  colnames(d) <- c("GROUP","SEQ","METHOD","FEATURE","CHR", "START","END","STRAND",
                   "PHASE","SCORE","PVALUE_OG","TRANSCRIPT_ID","EXTERNAL_NAM")
  if(slim==TRUE){
    d[, "SEQ"] <-  tolower(d[, "SEQ"])
    d <- unique(d[, col.old])
    for(r in col.old){
      d <- d[d[, r]!="", ]
    }
    d <- na.omit(d)
    rownames(d) <- c(1:nrow(d)) 
    colnames(d) <- col.new
  }
  return(d)
}

`microRNA.org2df.fun` <-
function(file=NULL, url=NULL, slim=TRUE,
                                col.old=c("Gene.ID", "miRNA"),
                                col.new=c("tran", "mir")){
  file <- getfile.fun(file=file, url=url)
  d <- read.table(file, header=TRUE, sep="\t", stringsAsFactor=FALSE)
  if(slim==TRUE){
    d <- unique(d[, col.old])
    d[, "miRNA"] <-  tolower(gsub("\\*","", d[, "miRNA"]))
    for(r in col.old){
      d <- d[d[, r]!="", ]
    }
    d <- na.omit(d)
    rownames(d) <- c(1:nrow(d)) 
    colnames(d) <- col.new
  }
  return(d)
}

`sam.probe.fun` <-
function(file){
  file <- getfile.fun(file=file)
  unique(as.vector(read.table(file)[, ]))
}

